<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
class ProductImage extends Model
{
    protected $fillable=['product_id','product_variant_id','path','alt_text','is_primary','sort_order'];
    protected function casts(): array { return ['is_primary'=>'boolean']; }
    public function product(){ return $this->belongsTo(Product::class); }
    public function variant(){ return $this->belongsTo(ProductVariant::class,'product_variant_id'); }
}
