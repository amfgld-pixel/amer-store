$ErrorActionPreference = 'Stop'
$ProjectRoot = (Get-Location).Path
$Controller = Join-Path $ProjectRoot 'app\Http\Controllers\ReceivableLoanController.php'

if (-not (Test-Path $Controller)) { throw 'ReceivableLoanController.php was not found.' }
$Text = Get-Content $Controller -Raw

$Markers = @(
    'PACK14AT_LOAN_CURRENT_LEDGER',
    "where('receivable_loan_transactions.type', '<>', 'reversal')",
    "whereColumn('reversal_rows.reverses_transaction_id', 'receivable_loan_transactions.id')"
)
foreach ($Marker in $Markers) {
    if (-not $Text.Contains($Marker)) { throw "Marker missing: $Marker" }
}

& php -l $Controller
if ($LASTEXITCODE -ne 0) { throw 'PHP syntax check failed.' }

& php artisan view:cache
if ($LASTEXITCODE -ne 0) { throw 'Blade view cache failed.' }

Write-Host 'Reversal rows hidden from live Loan Receivable ledger: OK' -ForegroundColor Green
Write-Host 'Reversed original transactions hidden from live Loan Receivable ledger: OK' -ForegroundColor Green
Write-Host 'Audit/history records preserved in database: OK' -ForegroundColor Green
Write-Host 'PACK14AT v3.8.114-R1 verification passed.' -ForegroundColor Green

