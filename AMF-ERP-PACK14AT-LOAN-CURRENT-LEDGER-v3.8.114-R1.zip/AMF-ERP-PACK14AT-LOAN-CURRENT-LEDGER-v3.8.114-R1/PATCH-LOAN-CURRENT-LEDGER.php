<?php

$root = $argv[1] ?? null;
if (!$root || !is_dir($root)) {
    fwrite(STDERR, "Laravel project root is invalid.\n");
    exit(1);
}

$file = rtrim($root, "\\/") . '/app/Http/Controllers/ReceivableLoanController.php';
if (!is_file($file)) {
    fwrite(STDERR, "Missing file: app/Http/Controllers/ReceivableLoanController.php\n");
    exit(1);
}

$text = file_get_contents($file);
$marker = 'PACK14AT_LOAN_CURRENT_LEDGER';
if (str_contains($text, $marker)) {
    echo "Loan current-ledger filter is already installed.\n";
    exit(0);
}

$pattern = <<<'REGEX'
~(?<indent>\s*)->where\(\s*['"](?:receivable_loan_transactions\.)?receivable_loan_id['"]\s*,\s*\$id\s*\)\s*->select\(~
REGEX;
$replacement = <<<'PHP'

            // PACK14AT_LOAN_CURRENT_LEDGER: live view excludes reversals and their superseded originals.
            ->where('receivable_loan_transactions.receivable_loan_id', $id)
            ->where('receivable_loan_transactions.type', '<>', 'reversal')
            ->whereNotExists(function ($query) {
                $query->selectRaw('1')
                    ->from('receivable_loan_transactions as reversal_rows')
                    ->whereColumn('reversal_rows.reverses_transaction_id', 'receivable_loan_transactions.id');
            })
            ->select(
PHP;

$updated = preg_replace($pattern, $replacement, $text, 1, $count);
if ($count !== 1 || !$updated || !str_contains($updated, $marker)) {
    fwrite(STDERR, "Compatible Loan Receivable transaction query was not found. No file was changed.\n");
    exit(1);
}

file_put_contents($file, $updated);
echo "Loan Receivable live ledger filter installed.\n";

