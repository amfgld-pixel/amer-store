PACK14AT v3.8.114-R1 - Loan Receivable Current Ledger

এই প্যাক শুধুমাত্র Loan Receivable-এর live ledger list পরিবর্তন করে।

যা হবে:
1. reversal row live ledger-এ দেখাবে না।
2. যে installment reverse হয়েছে, original installment-ও দেখাবে না।
3. যে salary adjustment payroll correction দিয়ে reverse হয়েছে, original adjustment-ও দেখাবে না।
4. বর্তমানে কার্যকর transaction-গুলোই দেখাবে।
5. Database, journal posting এবং Audit History থেকে কোনো record delete হবে না।

INSTALL:
PowerShell -ExecutionPolicy Bypass -File `
".\AMF-ERP-PACK14AT-LOAN-CURRENT-LEDGER-v3.8.114-R1\INSTALL-PACK14AT-v3.8.114-R1.ps1"

VERIFY:
PowerShell -ExecutionPolicy Bypass -File `
".\AMF-ERP-PACK14AT-LOAN-CURRENT-LEDGER-v3.8.114-R1\VERIFY-PACK14AT-v3.8.114-R1.ps1"
