$ErrorActionPreference = 'Stop'
$Version = 'v3.8.114-R1'
$ProjectRoot = (Get-Location).Path
$Controller = Join-Path $ProjectRoot 'app\Http\Controllers\ReceivableLoanController.php'
$Patch = Join-Path $PSScriptRoot 'PATCH-LOAN-CURRENT-LEDGER.php'
$Stamp = Get-Date -Format 'yyyyMMdd-HHmmss'
$BackupRoot = Join-Path $ProjectRoot "storage\pack14at-backups\$Version-$Stamp"

if (-not (Test-Path (Join-Path $ProjectRoot 'artisan'))) { throw 'Run this installer from the Laravel project root.' }
if (-not (Test-Path $Controller)) { throw 'ReceivableLoanController.php was not found.' }
if (-not (Test-Path $Patch)) { throw 'Patch program was not found.' }

New-Item -ItemType Directory -Path (Join-Path $BackupRoot 'app\Http\Controllers') -Force | Out-Null
Copy-Item $Controller (Join-Path $BackupRoot 'app\Http\Controllers\ReceivableLoanController.php') -Force

try {
    & php $Patch $ProjectRoot
    if ($LASTEXITCODE -ne 0) { throw 'Loan current-ledger patch failed.' }

    & php -l $Controller
    if ($LASTEXITCODE -ne 0) { throw 'PHP syntax check failed.' }

    & php artisan optimize:clear
    if ($LASTEXITCODE -ne 0) { throw 'Laravel cache clear failed.' }

    & php artisan view:cache
    if ($LASTEXITCODE -ne 0) { throw 'Blade view cache failed.' }

    Write-Host "PACK14AT $Version installed successfully." -ForegroundColor Green
    Write-Host "Backup: $BackupRoot"
}
catch {
    Copy-Item (Join-Path $BackupRoot 'app\Http\Controllers\ReceivableLoanController.php') $Controller -Force
    & php artisan optimize:clear | Out-Null
    throw "PACK14AT $Version failed. Original restored from $BackupRoot. $($_.Exception.Message)"
}

